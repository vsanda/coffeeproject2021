public class Customer {

    public int customerID;
    public String name;

    public Customer(int id, String name) {
        this.customerID = id;
        this.name = name;
    }
}
