import java.util.HashMap;

public class Inventory {

    private HashMap<String, Integer> inventory ;
}
