public class Ingredient {

    public String name;

    public Ingredient(String name){
        this.name = name;
    }
}
